document.addEventListener('DOMContentLoaded', function() {
    const hamburgerMenu = document.getElementById('hamburgerMenu');
    const mobileNavMenu = document.getElementById('mobileNavMenu');
    const mobileNavButtons = document.querySelectorAll('.nav-btn');
    
    let isMenuOpen = false;

    // Toggle mobile menu
    function toggleMobileMenu() {
        isMenuOpen = !isMenuOpen;
        mobileNavMenu.classList.toggle('hidden');
        
        // Update hamburger icon
        const icon = hamburgerMenu.querySelector('i');
        if (isMenuOpen) {
            icon.classList.remove('fa-bars');
            icon.classList.add('fa-times');
        } else {
            icon.classList.remove('fa-times');
            icon.classList.add('fa-bars');
        }

        // Add blur backdrop when menu is open
        if (isMenuOpen) {
            const backdrop = document.createElement('div');
            backdrop.id = 'mobile-menu-backdrop';
            backdrop.className = 'fixed inset-0 bg-black/20 backdrop-blur-sm z-40';
            backdrop.addEventListener('click', closeMobileMenu);
            document.body.appendChild(backdrop);
            document.body.style.overflow = 'hidden';
        } else {
            const backdrop = document.getElementById('mobile-menu-backdrop');
            if (backdrop) {
                backdrop.remove();
            }
            document.body.style.overflow = '';
        }
    }

    // Close mobile menu
    function closeMobileMenu() {
        if (isMenuOpen) {
            isMenuOpen = false;
            mobileNavMenu.classList.add('hidden');
            const icon = hamburgerMenu.querySelector('i');
            icon.classList.remove('fa-times');
            icon.classList.add('fa-bars');
            const backdrop = document.getElementById('mobile-menu-backdrop');
            if (backdrop) {
                backdrop.remove();
            }
            document.body.style.overflow = '';
        }
    }

    // Handle hamburger menu click
    hamburgerMenu?.addEventListener('click', toggleMobileMenu);

    // Handle navigation button clicks
    mobileNavButtons.forEach(button => {
        button.addEventListener('click', (e) => {
            e.preventDefault();
            const nav = button.dataset.nav;
            closeMobileMenu();
            // Handle navigation here based on data-nav value
            switch(nav) {
                case 'home':
                    window.location.href = '/';
                    break;
                case 'about':
                    window.location.href = '/about.html';
                    break;
                case 'contact':
                    window.location.href = '/contact.html';
                    break;
                // Add other navigation cases as needed
            }
        });
    });

    // Close menu on ESC key
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') {
            closeMobileMenu();
        }
    });
});